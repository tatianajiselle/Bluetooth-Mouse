#include <A3000.h>
#include <SPI.h>

//Defines
#define WRITE_BIT 	0x80 // When added to the address, sets MSB to 1 to indicate a write sequence
#define MOTION_BIT	0x80 // MOTION_ST == 1 (sensor is moving)
#define RESET_VALUE	0x5A // Write this into RESET register for a chip reset

// Contructors //////////////////////////////////////////////////////////////////////

A3000::A3000(void){
	dX = dY = 0;
	setClockFreq(1000000); // Max value - 1MHz
	setDataOrder(MSBFIRST);
	setDataMode(SPI_MODE0);
}

A3000::A3000(int freq, int order, int mode){
	dX = dY = 0;
	setClockFreq(freq);		// Value in Hz
	setDataOrder(order); 	// MSBFIRST, LSBFIRST
	setDataMode(mode);		// SPI_MODE0, SPI_MODE1, SPI_MODE2, SPI_MODE3
}

// Public Methods ///////////////////////////////////////////////////////////////////
void A3000::init(void){
	digitalWrite(SS, HIGH);
	SPI.begin();
}

void A3000::setClockFreq(int freq){ _speedMaximum = freq; }

void A3000::setDataOrder(int order){ _dataOrder = order; }

void A3000::setDataMode(int mode){ _dataMode = mode; }

void A3000::writeReg(regAddr reg, byte value){
	SPI.beginTransaction(SPISettings(getClockFreq(), getDataOrder(), getDataMode()));
	digitalWrite(SS, LOW);
	SPI.transfer16(((WRITE_BIT + (byte)reg) << 8) + value);
	digitalWrite(SS, HIGH);
	SPI.endTransaction();
}

byte A3000::readReg(regAddr reg){
	byte temp;
	SPI.beginTransaction(SPISettings(getClockFreq(), getDataOrder(), getDataMode()));
	digitalWrite(SS, LOW);
	temp = SPI.transfer((byte)reg);
	digitalWrite(SS, HIGH);
	SPI.endTransaction();
	return temp;
}

void A3000::readDeltaXY(void){
	if(readReg(MOTION_ST) == MOTION_BIT){
		dX = readReg(DELTA_X);
		dY = readReg(DELTA_Y);
	}
	else{ dX = dY = 0; }	
}

void A3000::readDeltaXYHigh(void){
	byte x, y, h;
	if(readReg(MOTION_ST) == MOTION_BIT){
		SPI.beginTransaction(SPISettings(getClockFreq(), getDataOrder(), getDataMode()));
		digitalWrite(SS, LOW);
		x = SPI.transfer((byte)DELTA_X);
		y = SPI.transfer((byte)DELTA_Y);
		h = SPI.transfer((byte)DELTA_XY_HIGH);
		digitalWrite(SS, HIGH);
		SPI.endTransaction();
		dX = (h >> 4) << 8 + x;
		dY = (h << 12) >> 8 + y;
	}
	else{ dX = dY = 0; }
}

void A3000::reset(void){ writeReg(RESET, RESET_VALUE); }

